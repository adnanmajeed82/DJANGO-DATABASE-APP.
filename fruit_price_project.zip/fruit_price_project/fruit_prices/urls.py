# fruit_prices/urls.py

from django.urls import path
from . import views

urlpatterns = [
    path('', views.fruit_prices_list, name='fruit_prices_list'),
]
